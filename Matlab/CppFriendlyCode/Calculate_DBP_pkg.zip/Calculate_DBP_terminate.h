/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Calculate_DBP_terminate.h
 *
 * Code generation for function 'Calculate_DBP_terminate'
 *
 */

#ifndef CALCULATE_DBP_TERMINATE_H
#define CALCULATE_DBP_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void Calculate_DBP_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (Calculate_DBP_terminate.h) */
