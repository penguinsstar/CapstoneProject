/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Calculate_DBP_terminate.c
 *
 * Code generation for function 'Calculate_DBP_terminate'
 *
 */

/* Include files */
#include "Calculate_DBP_terminate.h"
#include "Calculate_DBP_data.h"

/* Function Definitions */
void Calculate_DBP_terminate(void)
{
  omp_destroy_nest_lock(&emlrtNestLockGlobal);
  isInitialized_Calculate_DBP = false;
}

/* End of code generation (Calculate_DBP_terminate.c) */
