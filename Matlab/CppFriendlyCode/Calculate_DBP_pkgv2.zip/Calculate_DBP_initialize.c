/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Calculate_DBP_initialize.c
 *
 * Code generation for function 'Calculate_DBP_initialize'
 *
 */

/* Include files */
#include "Calculate_DBP_initialize.h"
#include "Calculate_DBP_data.h"

/* Function Definitions */
void Calculate_DBP_initialize(void)
{
  omp_init_nest_lock(&emlrtNestLockGlobal);
  isInitialized_Calculate_DBP = true;
}

/* End of code generation (Calculate_DBP_initialize.c) */
